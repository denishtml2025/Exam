// Paste your values from Supabase → Project Settings → API.
// The anon key is meant to be public; the database rules in supabase.sql keep data safe.
window.PP_CONFIG = {
  url: 'https://YOUR-PROJECT.supabase.co',
  key: 'YOUR-ANON-KEY'
};
