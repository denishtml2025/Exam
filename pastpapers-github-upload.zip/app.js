(() => {
'use strict';
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cfg = window.PP_CONFIG;
if (!cfg || cfg.url.includes('YOUR-PROJECT')) {
  document.body.innerHTML = '<p style="padding:2rem;font-family:system-ui">Open <b>config.js</b> and paste your Supabase URL and anon key.</p>';
  return;
}
const sb = supabase.createClient(cfg.url, cfg.key);

let user = null, papers = [], pays = [], settings = { phone: '', name: '', price: 0 };
const isAdmin = () => user && user.role === 'admin';
const kes = n => 'KSh ' + Number(n).toLocaleString();

function toast(msg) {
  $('toastText').textContent = msg;
  const t = $('toast'); t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 3000);
}
const busy = (form, on) => form.querySelectorAll('button[type=submit]').forEach(b => b.disabled = on);

/* ---------- auth ---------- */
function showAuth(signup) {
  $('loginForm').classList.toggle('hidden', signup);
  $('signupForm').classList.toggle('hidden', !signup);
  $('authSub').textContent = signup ? 'Create a student account' : 'Sign in to continue';
}
$('toSignup').onclick = () => showAuth(true);
$('toLogin').onclick = () => showAuth(false);

$('loginForm').onsubmit = async e => {
  e.preventDefault(); busy(e.target, true);
  const { data, error } = await sb.auth.signInWithPassword({ email: $('liEmail').value.trim(), password: $('liPass').value });
  busy(e.target, false);
  if (error) return toast('Wrong email or password.');
  e.target.reset(); enter(data.user);
};
$('signupForm').onsubmit = async e => {
  e.preventDefault(); busy(e.target, true);
  const { data, error } = await sb.auth.signUp({
    email: $('suEmail').value.trim(), password: $('suPass').value,
    options: { data: { name: $('suName').value.trim() } }
  });
  busy(e.target, false);
  if (error) return toast(error.message);
  e.target.reset();
  if (data.session) enter(data.user);
  else { toast('Check your email to confirm your account, then sign in.'); showAuth(false); }
};
$('logoutBtn').onclick = async () => {
  await sb.auth.signOut(); user = null;
  $('dashboard').classList.add('hidden'); $('authScreen').classList.remove('hidden'); showAuth(false);
};

async function enter(authUser) {
  const { data: prof } = await sb.from('profiles').select('name,role').eq('id', authUser.id).single();
  user = { id: authUser.id, email: authUser.email, name: prof ? prof.name : 'Student', role: prof ? prof.role : 'student' };
  $('authScreen').classList.add('hidden');
  $('dashboard').classList.remove('hidden');
  $('welcome').textContent = 'Signed in as ' + user.name;
  $('roleBadge').innerHTML = isAdmin() ? '<i class="fa-solid fa-user-shield"></i> Admin' : '<i class="fa-solid fa-graduation-cap"></i> Student';
  document.querySelectorAll('.admin-only').forEach(el => el.classList.toggle('hidden', !isAdmin()));
  $('payTitle').textContent = isAdmin() ? 'All payments' : 'My payments';
  $('upYear').value = new Date().getFullYear();
  setTab('papers');
  await loadAll();
}

/* ---------- data ---------- */
async function loadAll() {
  const [p, y, s] = await Promise.all([
    sb.from('papers').select('*').order('created_at', { ascending: false }),
    sb.from('payments').select('*').order('created_at', { ascending: false }),
    sb.from('settings').select('*').eq('id', 1).single()
  ]);
  if (p.error || y.error || s.error) return toast('Could not load data. Check your connection and database setup.');
  papers = p.data; pays = y.data; settings = s.data;
  $('sPhone').value = settings.phone; $('sName').value = settings.name; $('sPrice').value = settings.price;
  render();
}
window.addEventListener('focus', () => { if (user) loadAll(); });

/* ---------- tabs ---------- */
function setTab(name) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('active', p.id === 'panel-' + name));
}
$('tabs').onclick = e => { const b = e.target.closest('.tab-btn'); if (b) setTab(b.dataset.tab); };

/* ---------- render ---------- */
const empty = (cols, icon, text) => `<tr class="empty-row"><td colspan="${cols}"><i class="fa-solid ${icon}"></i>${text}</td></tr>`;
const pill = s => `<span class="pill ${s}">${s[0].toUpperCase() + s.slice(1)}</span>`;
// students only ever receive their own payments (enforced by the database)
const myPay = id => pays.find(p => p.paper_id === id && p.user_id === user.id && p.status !== 'rejected') || pays.find(p => p.paper_id === id && p.user_id === user.id);
const unlocked = p => isAdmin() || settings.price === 0 || pays.some(x => x.paper_id === p.id && x.user_id === user.id && x.status === 'confirmed');

function render() {
  const confirmed = pays.filter(p => p.status === 'confirmed');
  const stats = isAdmin() ? [
    ['blue', 'fa-file-lines', 'Papers', papers.length],
    ['orange', 'fa-hourglass-half', 'Pending', pays.filter(p => p.status === 'pending').length],
    ['green', 'fa-circle-check', 'Confirmed', confirmed.length],
    ['purple', 'fa-coins', 'Revenue', kes(confirmed.reduce((t, p) => t + p.amount, 0))]
  ] : [
    ['blue', 'fa-file-lines', 'Papers', papers.length],
    ['orange', 'fa-hourglass-half', 'Pending', pays.filter(p => p.status === 'pending').length],
    ['green', 'fa-lock-open', 'Unlocked', confirmed.length],
    ['purple', 'fa-tag', 'Price', settings.price ? kes(settings.price) : 'Free']
  ];
  $('stats').innerHTML = stats.map(([c, i, l, v]) => `<div class="stat-card"><div class="stat-icon ${c}"><i class="fa-solid ${i}"></i></div><div class="stat-info"><div class="label">${l}</div><div class="value">${esc(v)}</div></div></div>`).join('');

  const q = $('search').value.trim().toLowerCase();
  const list = papers.filter(p => (p.title + p.subject + p.level + p.year).toLowerCase().includes(q));
  $('paperBody').innerHTML = list.length ? list.map(p => {
    let act;
    if (isAdmin()) act = `<button class="icon-btn" data-dl="${p.id}" title="Download" aria-label="Download"><i class="fa-solid fa-download"></i></button><button class="icon-btn danger" data-del="${p.id}" title="Delete" aria-label="Delete"><i class="fa-solid fa-trash"></i></button>`;
    else if (unlocked(p)) act = `<button class="btn-sm success" data-dl="${p.id}"><i class="fa-solid fa-download"></i> Download</button>`;
    else { const m = myPay(p.id); act = m && m.status === 'pending' ? pill('pending') : `<button class="btn-sm" data-pay="${p.id}"><i class="fa-solid fa-lock"></i> Unlock ${kes(settings.price)}</button>${m && m.status === 'rejected' ? ' ' + pill('rejected') : ''}`; }
    return `<tr><td><div class="cell-name"><span class="cell-icon"><i class="fa-solid fa-file-pdf"></i></span>${esc(p.title)}</div></td><td>${esc(p.subject)}</td><td>${esc(p.level)} · ${esc(p.year)}</td><td><div class="action-row">${act}</div></td></tr>`;
  }).join('') : empty(4, 'fa-folder-open', papers.length ? 'No papers match your search.' : (isAdmin() ? 'No papers yet. Upload one above.' : 'No papers have been added yet.'));

  $('payBody').innerHTML = pays.length ? pays.map(p => `<tr><td>${esc(p.paper_title)}</td><td>${esc(p.name)}</td><td><code>${esc(p.code)}</code></td><td>${kes(p.amount)}</td><td>${pill(p.status)}</td><td>${isAdmin() && p.status === 'pending' ? `<div class="action-row"><button class="icon-btn success" data-ok="${p.id}" title="Confirm" aria-label="Confirm"><i class="fa-solid fa-check"></i></button><button class="icon-btn danger" data-no="${p.id}" title="Reject" aria-label="Reject"><i class="fa-solid fa-xmark"></i></button></div>` : '–'}</td></tr>`).join('')
    : empty(6, 'fa-receipt', isAdmin() ? 'No payments received yet.' : 'You have not made any payments yet.');
}
$('search').oninput = render;

/* ---------- row actions ---------- */
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-dl],[data-del],[data-pay],[data-ok],[data-no]');
  if (!b) return;
  const d = b.dataset;
  if (d.dl) {
    const p = papers.find(x => x.id === d.dl); if (!p) return;
    const { data, error } = await sb.storage.from('papers').createSignedUrl(p.file_path, 60, { download: p.file_name });
    if (error) return toast('Download not allowed yet. Payment must be confirmed.');
    const a = document.createElement('a'); a.href = data.signedUrl; a.click();
  } else if (d.del) {
    if (!confirm('Delete this paper?')) return;
    const p = papers.find(x => x.id === d.del);
    const { error } = await sb.from('papers').delete().eq('id', d.del);
    if (error) return toast('Could not delete the paper.');
    if (p) await sb.storage.from('papers').remove([p.file_path]);
    toast('Paper deleted.'); loadAll();
  } else if (d.pay) openPay(d.pay);
  else {
    const { error } = await sb.from('payments').update({ status: d.ok ? 'confirmed' : 'rejected' }).eq('id', d.ok || d.no);
    if (error) return toast('Could not update the payment.');
    toast(d.ok ? 'Payment confirmed.' : 'Payment rejected.'); loadAll();
  }
});

/* ---------- upload (admin) ---------- */
$('uploadForm').onsubmit = async e => {
  e.preventDefault();
  const f = $('upFile').files[0]; if (!f) return;
  if (f.size > 20 * 1024 * 1024) return toast('File is over 20 MB. Compress it and try again.');
  const path = Date.now() + '-' + f.name.replace(/[^\w.\-]+/g, '_');
  const form = $('uploadForm').closest('.section-card'); busy(form, true);
  const up = await sb.storage.from('papers').upload(path, f);
  if (up.error) { busy(form, false); return toast('Upload failed: ' + up.error.message); }
  const ins = await sb.from('papers').insert({ title: $('upTitle').value.trim(), subject: $('upSubject').value, level: $('upLevel').value, year: $('upYear').value, file_path: path, file_name: f.name });
  busy(form, false);
  if (ins.error) { await sb.storage.from('papers').remove([path]); return toast('Could not save the paper.'); }
  e.target.reset(); $('upYear').value = new Date().getFullYear();
  toast('Paper uploaded.'); loadAll();
};

/* ---------- payment modal (student) ---------- */
let payFor = null;
function openPay(id) {
  const p = papers.find(x => x.id === id); if (!p) return;
  payFor = p;
  $('mPaper').textContent = p.title; $('mPhone').textContent = settings.phone; $('mName').textContent = settings.name; $('mAmount').textContent = kes(settings.price);
  $('modal').classList.add('open'); $('mCode').focus();
}
const closePay = () => { $('modal').classList.remove('open'); $('payForm').reset(); payFor = null; };
$('mCancel').onclick = closePay;
$('modal').onclick = e => { if (e.target === $('modal')) closePay(); };
document.addEventListener('keydown', e => { if (e.key === 'Escape') closePay(); });
$('payForm').onsubmit = async e => {
  e.preventDefault(); if (!payFor) return; busy(e.target, true);
  const { error } = await sb.from('payments').insert({
    paper_id: payFor.id, paper_title: payFor.title, user_id: user.id, name: user.name,
    code: $('mCode').value.trim().toUpperCase(), amount: settings.price
  });
  busy(e.target, false);
  if (error) return toast(error.code === '23505' ? 'That code has already been used.' : 'Could not submit the payment.');
  closePay(); toast('Payment submitted. Waiting for admin confirmation.'); loadAll();
};

/* ---------- settings (admin) ---------- */
$('settingsForm').onsubmit = async e => {
  e.preventDefault();
  const { error } = await sb.from('settings').update({ phone: $('sPhone').value.trim(), name: $('sName').value.trim(), price: Math.max(0, Math.floor(Number($('sPrice').value) || 0)) }).eq('id', 1);
  if (error) return toast('Could not save settings.');
  toast('Settings saved.'); loadAll();
};
$('passForm').onsubmit = async e => {
  e.preventDefault();
  const { error } = await sb.auth.updateUser({ password: $('sNewPass').value });
  if (error) return toast(error.message);
  e.target.reset(); toast('Password updated.');
};

sb.auth.getSession().then(({ data }) => data.session ? enter(data.session.user) : showAuth(false));
})();
